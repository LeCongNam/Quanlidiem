
<div id="banner">
    <div class="banner__learn-more">
        <h2>Lorem ipsum dolor sit amet</h2>
        <p class="p-first">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto dignissimos vel
            debitis, vitae facere
            autem qui molestiae ratione iure consectetur odio adipisci laboriosam excepturi ad quos atque
            explicabo asperiores at.
        </p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est voluptas fugit quasi voluptatibus alias
            eaque, esse ipsa animi ipsam exercitationem ea dolore nobis natus reiciendis accusantium id iure
            accusamus corrupti!
        </p>
        <button class="btn-primary mt-20">Learn More </button>
    </div>
    <div class="banner__image">
        <img src="resources/image/banner.png" alt="banner.png" class="banner__img">
    </div>
</div>

