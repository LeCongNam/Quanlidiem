<footer>
    <div class="footer-session">
        <div class="f-last">
            <h2 class="time-title">Lastest Post</h2>
            <!-- divison column -->
            <div class="time">
                <button class="btn-time">
                    <p>JULY</p>
                    <h5>27</h5>
                </button>
                <div class="post">
                    <h5 class="title">Aliquam et iaculises sapine</h5>
                    <p class="desc">Vertibulum pulvinar tincidunt placerat</p>
                </div>
            </div>
            <!-- divison column -->
            <div class="time">
                <button class="btn-time">
                    <p>JULY</p>
                    <h5>27</h5>
                </button>
                <div class="post">
                    <h5 class="title">Aliquam et iaculises sapine</h5>
                    <p class="desc">Vertibulum pulvinar tincidunt placerat</p>
                </div>
            </div>
            <!-- divison column -->
            <div class="time">
                <button class="btn-time">
                    <p>JULY</p>
                    <h5>27</h5>
                </button>
                <div class="post">
                    <h5 class="title">Aliquam et iaculises sapine</h5>
                    <p class="desc">Vertibulum pulvinar tincidunt placerat</p>
                </div>
            </div>
        </div>
        <div class="f-about">
            <h4 class="about-title">About</h4>
            <p class="about__desc mt-20">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iste commodi
                possimus similique a earum
                officia, ut aspernatur cum incidunt aliquam obcaecati explicabo cupiditate molestias ea
                recusandae soluta pariatur tempora vitae.</p>
            <p class="about__desc mt-20">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quae, at. Ex
                harum
                earum, laboriosam fugiat voluptatem quis molestiae.</p>
        </div>
        <div class="f-connect">
            <h3 class="connect-title">Stay Connected</h3>
            <div class="social">
                <div class="connect">
                    <i class="fab fa-facebook-square icon"></i>
                    <span class="connect-name">FaceBook</span>
                </div>
                <div class="connect">
                    <i class="fab fa-twitter-square icon"></i>
                    <span class="connect-name">Twitter</span>
                </div>
                <div class="connect">
                    <i class="fas fa-rss-square icon"></i>
                    <span class="connect-name">RSS</span>
                </div>
                <div class="connect">
                    <i class="fab fa-google-plus-square icon"></i>
                    <span class="connect-name">Google+</span>
                </div>
            </div>
        </div>
    </div>
</footer>
