<?php $__env->startSection('dashboard'); ?>

    <link rel="stylesheet" href="/css/diem.css">

    <style>
        .sv {
            font-weight: bolder;
            color: rgb(206, 50, 50)
        }

        .sv.name {
            text-transform: uppercase
        }

    </style>

    
    <div class="container">
        <div class="row">
            <h4 class="d-flex justify-content-center mb-5 mt-4">Kết Quả học tập của sinh viên</h4>
        </div>
        <div class="row">
            <table class="table table-striped">
                <thead>
                    <tr>
                        
                        <th scope="col">#</th>
                        <th scope="col">Tên sinh viên</th>
                        <th scope="col">Mã số sinh viên</th>
                        <th scope="col">Tên môn học</th>
                        <th scope="col">Điểm</th>
                        <th scope="col">Số tín chỉ</th>
                        <th scope="col">lần thi</th>
                        <th scope="col">Lớp</th>
                        <th scope="col">Khoa</th>
                        <th scope="col" colspan="2">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $pos = 0; ?>

                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            
                            <td><?php echo e(++$pos); ?></td>
                            <td class="sv name"><?php echo e($row->tensv); ?></td>
                            <td class="sv name"><?php echo e($row->masv); ?></td>
                            <td><?php echo e($row->tenmh); ?></td>
                            <td><?php echo e($row->diem); ?></td>
                            <td><?php echo e($row->sotc); ?></td>
                            <td><?php echo e($row->lanthi); ?></td>
                            <td><?php echo e($row->lop); ?></td>
                            <td><?php echo e($row->tenkhoa); ?></td>
                            <td>
                                <a href="/admin/edit/<?php echo e($row->id); ?>" class="btn btn-primary">Sửa</a>
                            </td>
                            <td>
                                
                                <a class="btn btn-danger" onclick="return confirm('Are you sure?')"
                                    href="<?php echo e(route('scores-delete', $row->id)); ?>">
                                    <i class="fa fa-trash"></i>
                                    Xoá
                                </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('/Template/adminTemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quanlidiem\resources\views/AdminDashboard.blade.php ENDPATH**/ ?>