

<?php $__env->startSection('xemdiem'); ?>

<link rel="stylesheet" href="/css/diem.css">
 
    
   

        <div class="row wrap-info">
         
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                    <ul>
                        <li>
                            <span>Họ tên sinh viên:</span>
                            <b><?php echo e($row->tensv); ?></b>
                        </li>
                        <li>
                            <span>ngày sinh:</span>
                            <b><?php echo e(date('d-m-Y', strtotime($row->ngaysinh))); ?></b>
                        </li>
                        <li>
                            <span>ngày sinh:</span>
                            <b><?php echo e($row->tenkhoa); ?></b>
                        </li>
                        <li>
                            <span>Nơi Sinh:</span>
                            <b><?php echo e($row->noisinh); ?></b>
                        </li>
                        <li>
                            <span>Lớp: </span>
                            <b><?php echo e($row->lop); ?></b>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
              
                <div class="col">
                    <ul>
                      <li>
                          <span>Hình ảnh sinh viên</span>
                      </li>
                        <li>
                           <img src="<?php echo e($row->hinhsv); ?>" alt="<?php echo e($row->tensv); ?>" class="imgsv">
                        </li>
                       
                       
                    </ul>
                </div>
               
        </div>
    </div>


    
    <div class="container">
        <div class="row">
            <div class="col">
                <h4 class="d-flex justify-content-center mb-2">Kết quả học tập</h4>
            </div>
        </div>
        <div class="row">
            <table class="table table-striped border-table" id="scores-table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tên môn học</th>
                        <th scope="col">Điểm</th>
                        <th scope="col">Số tín chỉ</th>
                        <th scope="col">lần thi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $pos=0 ?>

                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                      
                        <td><?php echo e(++$pos); ?></td>
                        <td><?php echo e($row->tenmh); ?></td>
                        <td><?php echo e($row->diem); ?></td>
                        <td><?php echo e($row->sotc); ?></td>
                        <td><?php echo e($row->lanthi); ?></td>
                        
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
 
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/Template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quanlidiem\resources\views/XemDiem.blade.php ENDPATH**/ ?>