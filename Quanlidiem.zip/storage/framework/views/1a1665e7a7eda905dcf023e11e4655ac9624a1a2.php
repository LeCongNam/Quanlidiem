

<?php $__env->startSection('home'); ?>
    <style>
        .error {
            color: red;
        }

        .success {
            color: #2ca02c;
        }

      

        .form-search{
            position: absolute !important;
            top: 90%;
            left: 9%;
            font-size: 16px;
            width: 40%;
            margin-bottom: 1000px;
            /* z-index: 1; */

        }
    </style>

<div class="form-search">
    

    <?php echo Form::open(['url' => '/search', 'files' => true]); ?>

    <h4>Tìm kiếm Sinh viên</h4>

    <?php if(count($errors) > 0): ?>
        LỖI <br>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="error">
                <b> <?php echo e($err); ?></b>
            </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(isset($mess)): ?>
        <div class="success">
            <?php echo e($mess); ?>

        </div>
    <?php endif; ?>

    <?php echo e(Form::label('masv', 'Mã Sinh viên')); ?>

    <?php echo e(Form::text('masv', '', ['class' => 'form-control', 'placeholder' => 'Nhập mã sinh viên'])); ?> <?php echo e(Form::submit('Sreach', ['class' => 'btn btn-primary btn-block mt-3'])); ?>


    
    <?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/Template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quanlidiem\resources\views/SearchAndLogin.blade.php ENDPATH**/ ?>