
<?php $__env->startSection('editScores'); ?>
    <style>
        .error {
            color: red;
        }

        .success {
            color: #2ca02c;
        }

 

    </style>

    <div class="container">
        <div class="row">
            <div class="col-6 m-auto">



                <?php echo Form::open(['url' => '/admin/update', 'files' => true]); ?>

                <h3 style="text-align: center">CẬP NHẬT THÔNG TIN KẾT QUẢ HỌC TẬP</h3>
                <hr>

                <?php if(count($errors) > 0): ?>
                    LỖI <br>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="error">
                            <b> <?php echo e($err); ?></b>
                        </div><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(isset($mess)): ?>
                    <div class="success">
                        <?php echo e($mess); ?>

                    </div>
                <?php endif; ?>

                    <?php if(isset($scores)): ?>
                     
                        <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e(Form::hidden('id', $row->id)); ?>


                        <?php echo e(Form::label('masv', 'Mã số sinh viên')); ?>

                        <?php echo e(Form::text('masv', $row->masv, ['class' => 'form-control','readonly' => 'true','placeholder' => 'Nhập mssv'])); ?>


                        <?php echo e(Form::label('tenmh', 'Tên Môn Học')); ?>

                        <?php echo e(Form::text('tenmh', $row->tenmh, ['class' => 'form-control', 'placeholder' => 'Nhập Tên môn học'])); ?>


                        <?php echo e(Form::label('sotc', 'Số tín chỉ')); ?>

                        <?php echo e(Form::number('sotc', $row->sotc, ['class' => 'form-control', 'readonly' => 'true'])); ?>


                        <?php echo e(Form::label('diem', 'Điểm')); ?>

                        <?php echo e(Form::number('diem', $row->diem, ['class' => 'form-control'])); ?>



                        <?php echo e(Form::label('lop', 'Lớp')); ?>

                        <?php echo e(Form::text('lop', $row->lop, ['class' => 'form-control', 'readonly' => 'true', 'placeholder' => 'Nhập Lớp'])); ?>


                        <?php echo e(Form::label('lanthi', 'Lần  thi')); ?>

                        <?php echo e(Form::number('lanthi', $row->lanthi, ['class' => 'form-control'])); ?>

                        <?php echo e(Form::submit('Cập nhật', ['class' => 'btn btn-primary btn-block mt-3'])); ?>

                        <?php echo Form::close(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    <?php else: ?>
                    <?php echo e(Form::hidden('id', '')); ?>


                    <?php echo e(Form::label('masv', 'Mã số sinh viên')); ?>

                    <?php echo e(Form::text('masv','', ['class' => 'form-control','readonly' => 'true','placeholder' => 'Nhập mssv'])); ?>


                    <?php echo e(Form::label('tenmh', 'Tên Môn Học')); ?>

                    <?php echo e(Form::text('tenmh','', ['class' => 'form-control', 'placeholder' => 'Nhập Tên môn học'])); ?>


                    <?php echo e(Form::label('sotc', 'Số tín chỉ')); ?>

                    <?php echo e(Form::number('sotc','', ['class' => 'form-control', 'readonly' => 'true'])); ?>


                    <?php echo e(Form::label('diem', 'Điểm')); ?>

                    <?php echo e(Form::number('diem','', ['class' => 'form-control'])); ?>



                    <?php echo e(Form::label('lop', 'Lớp')); ?>

                    <?php echo e(Form::text('lop','', ['class' => 'form-control', 'readonly' => 'true', 'placeholder' => 'Nhập Lớp'])); ?>


                    <?php echo e(Form::label('lanthi', 'Lần  thi')); ?>

                    <?php echo e(Form::number('lanthi','', ['class' => 'form-control'])); ?>

                    <?php echo e(Form::submit('Cập nhật', ['class' => 'btn btn-primary btn-block mt-3'])); ?>

                    <?php echo Form::close(); ?>

                    <?php endif; ?>

            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('/Template/adminTemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quanlidiem\resources\views/EditScore.blade.php ENDPATH**/ ?>